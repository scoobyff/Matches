declare const PLAYER_VERSION: string

declare module 'shaka-player' {
  export = shaka
}
