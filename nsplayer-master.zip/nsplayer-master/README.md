# NSPlayer

  [![NPM Version][npm-image]][npm-url]

## Installation

## LICENSE

MIT

[npm-image]: https://img.shields.io/npm/v/nsplayer.svg?style=flat-square
[npm-url]: https://npmjs.org/package/nsplayer
