// import NSPlayer from '../src'

test('NSPlayer', () => {
  // const player = new NSPlayer()
  // expect(player).not.toBeNull()
})
